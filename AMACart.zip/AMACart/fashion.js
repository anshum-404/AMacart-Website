// Write JavaScript here 

var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}


var mybutton = document.getElementById("myBtn");


window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}


function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
function fs(x)
{
    x.style.backgroundColor="pink";
}
function sb()
{
    alert("YOUR FEEDBACK IS SUBMITTED!!");
}
function fx()
{
    alert("Your Order has been placed!....");
    alert("An email will be sent regarding payment option..");
}